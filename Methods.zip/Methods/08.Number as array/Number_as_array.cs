﻿/*
Problem 8. Number as array
• Write a method that adds two positive integer numbers represented as arrays of digits (each array element  arr[i]  contains a digit; the last digit is kept in  arr[0] ).
• Each of the numbers that will be added could have up to  10 000  digits.
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Number_as_array
{
    class Number_as_array
    {

        public static void AddTwoNumbersAsArrays(string firstNumber, string secondNumber)
        {
            int[] arrayOfTheFirstNumber = firstNumber.Select(x => (int)(x - 48)).ToArray();
            int[] arrayOfTheSecondNumber = secondNumber.Select(x => (int)(x - 48)).ToArray();

            Array.Reverse(arrayOfTheFirstNumber);
            Array.Reverse(arrayOfTheSecondNumber);

            List<int> resultList = new List<int>(Math.Max(arrayOfTheFirstNumber.Length, arrayOfTheSecondNumber.Length));

            int remainder = 0;

            for (int i = 0; i < resultList.Capacity; i++)
            {
                int number = (i<arrayOfTheFirstNumber.Length? arrayOfTheFirstNumber[i] :0)+ (i<arrayOfTheSecondNumber.Length? arrayOfTheSecondNumber[i]:0) + remainder;
                remainder = number / 10;
                resultList.Add(number % 10);
            }

            if (remainder > 0)
            {
                resultList.Add(remainder);
            }

            for (int i = resultList.Count-1; i >= 0; i--)
            {
                Console.Write(resultList[i]);
            }
            Console.WriteLine();
        }

        static void Main(string[] args)
        {
            string firstNumber,secondNumber;

            Console.Write("Please, enter first array length (up to 10 000) : ");
            firstNumber=Console.ReadLine();

            Console.Write("Please, enter second array length (up to 10 000 digit) : ");
            secondNumber = Console.ReadLine();
            
            AddTwoNumbersAsArrays(firstNumber, secondNumber);

            
        }
    }
}
