﻿/*

Problem 2. Get largest number
• Write a method  GetMax()  with two parameters that returns the larger of two integers.
• Write a program that reads  3  integers from the console and prints the largest of them using the method  GetMax() .
 */ 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Get_largest_number
{
    class Get_largest_number
    {

        public static int GetMax(int firstNumber,int secondNumber)
        {
            if(firstNumber > secondNumber)
            {
                return firstNumber;
            }
            else if (firstNumber < secondNumber)
            {
                return secondNumber;
            }
            else
            {
                return -1;
            }
            
        }

        static void Main(string[] args)
        {
            int firstNumber;
            int secondNumber;
            int maxNumber;

            Console.Write("Please enter the first number : ");
            firstNumber=int.Parse(Console.ReadLine());

            Console.Write("Please enter the second number : ");
            secondNumber = int.Parse(Console.ReadLine());

            maxNumber = GetMax(firstNumber, secondNumber);

            if(maxNumber==-1)
            {
                Console.WriteLine("The numbers are equal");
            }
            else
            {
                Console.WriteLine("{0} is bigger !",maxNumber);
            }
        }
    }
}
