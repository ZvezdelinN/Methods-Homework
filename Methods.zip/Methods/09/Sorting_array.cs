﻿/*
Problem 9. Sorting array
• Write a method that return the maximal element in a portion of array of integers starting at given index.
• Using it write another method that sorts an array in ascending / descending order.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sorting_array
{
    class Sorting_array
    {
        public static int[] GetMaxValueInSubArray(int[] arrayToSearch, int startPopsition, int endPosition)
        {
            int[] newArray = new int[endPosition - startPopsition];
            for (int i = 0,j=startPopsition; i < endPosition-startPopsition; i++,j++)
            {
                newArray[i]=arrayToSearch[j];
            }
            return newArray;
        }

        public static int[] SortArray(int[] arrayToSort)
        {
            int wayToSort;
            Console.Write("Please enter 1(ascending) or 2(descending) way to sort an array : ");
            wayToSort = int.Parse(Console.ReadLine());

            if (wayToSort==1)
            {
                Array.Sort(arrayToSort);
                return arrayToSort;
            }
            else if (wayToSort==2)
            {
                Array.Sort(arrayToSort);
                Array.Reverse(arrayToSort);
                
                return arrayToSort;
            }
            else
            {
                Console.WriteLine("Invalid number");
                return new int[1];
            }
        }

        static void Main(string[] args)
        {
            int[] array1 = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            int[] array2 = new int[array1.Length];

            int start=2,end=5,maxValue;

            array2 = GetMaxValueInSubArray(array1, start, end);

            array2 = SortArray(array2);
            for (int i = 0; i < array2.Length; i++)
            {
                Console.Write(array2[i]+" ");
            }
            Console.WriteLine();

            maxValue = array2.Max();

            Console.WriteLine("The max is {0}",maxValue);
 
        }
    }
}
