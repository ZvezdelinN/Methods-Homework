﻿/*
Problem 10. N Factorial
• Write a program to calculate  n!  for each  n  in the range [ 1..100 ].

Hint: Implement first a method that multiplies a number represented as array of digits by given integer number
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace N_Factorial
{
    class N_Factorial
    {
        public static List<int> SumArrays(List<int> firstList,List<int> secondList)
        {
            List<int> resultList = new List<int>(Math.Max(firstList.Count, secondList.Count));

            int remainder = 0;

            for (int i = 0; i < resultList.Capacity; i++)
            {
                int number = (i < firstList.Count ? firstList[i] : 0) + (i < secondList.Count ? secondList[i] : 0) + remainder;
                remainder = number / 10;
                resultList.Add(number % 10);
            }

            if (remainder > 0)
            {
                resultList.Add(remainder);
            }

            return resultList;
        }

        public static void Main()
        {
            int[] array1 = { 1, 2, 3, 4 };
            int[] array2 = { 1, 0 };
            int buffer = 1,number=10;
            List<int> lst = new List<int>(100){1};

            List<List<int>> dbllst = new List<List<int>>(array2.Length);

            int remainder = 0;
            
            #region Try


            for (int i = 1; i < number; i++)
            {
                for (int j = 0; j < lst.Capacity; j++)
                {
                    buffer = lst[j] * i + remainder;
                    remainder = buffer / 10;
                    lst.Add(buffer % 10);
                }
                if (remainder > 0)
                    lst.Add(remainder);
            }

            for (int i = lst.Count-1; i >= 0; i--)
            {
                Console.Write(lst[i]);
            }

            #endregion






            //    Array.Reverse(array1);
        //    Array.Reverse(array2);

        //    for (int i = 0; i < dbllst.Capacity; i++)
        //    {
        //        lst=new List<int>();
        //        for (int j = 0; j < array1.Length; j++)
        //        {

        //            buffer = array2[i] * (array1[j]*Convert.ToInt32(Math.Pow(10.0,double.Parse(i.ToString())))) + remainder;
        //            remainder = buffer / 10;
        //            lst.Add(buffer % 10);
        //        }
        //        if (remainder > 0)
        //        {
        //            lst.Add(remainder);
        //        }
        //        dbllst.Add(lst);
        //    }


        //    lst = SumArrays(dbllst[0], dbllst[1]);

        //    for (int i = 2; i < dbllst.Count; i++)
        //    {
        //        lst = SumArrays(lst, dbllst[i]);
        //    }

        //    for (int i = lst.Count-1; i >= 0; i--)
        //    {
        //        Console.Write(lst[i]);
        //    }
        }
    }
}