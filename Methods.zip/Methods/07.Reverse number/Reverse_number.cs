﻿/*
Problem 7. Reverse number
• Write a method that reverses the digits of given decimal number.

Example:

input           output

256                652 
123.45          54.321 
 */ 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reverse_number
{
    class Reverse_number
    {
        public static double ReverceNumber(double numberToReverce)
        {
            char[] charElementsOfDouble = numberToReverce.ToString().ToCharArray();
            double revercedDouble = 0;

            charElementsOfDouble=ReverceArray(charElementsOfDouble);
            
            string stringNumber = "";
            stringNumber = new string(charElementsOfDouble);
            return revercedDouble = double.Parse(stringNumber);

        }

        public static char[] ReverceArray(char[] chrArray)
        {
            char[] revercedArray=new char[chrArray.Length];
            
            for (int i = 0,j = revercedArray.Length - 1; i < chrArray.Length; i++,j--)
			{
			   revercedArray[i]=chrArray[j];
			}
            return revercedArray;
            
        }
        static void Main(string[] args)
        {
            Console.Write("Please enter a number to reverse : ");
            string strNumber = Console.ReadLine();
            double dblNumber=0.0;

            if(double.TryParse(strNumber,out dblNumber))
            {
                dblNumber = ReverceNumber(dblNumber);
                Console.WriteLine(dblNumber);
            }
            else
            {
                throw new ArgumentException("Invalid dblNumber");
            }



        }
    }
}
