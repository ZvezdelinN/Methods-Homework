﻿/*
Problem 4. Appearance count
• Write a method that counts how many times given number appears in given array.
• Write a test program to check if the method is workings correctly.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Appearance_count
{
    class Appearance_count
    {
        public static int CountingNumbers(int[] arrayToCheck, int numberToFind)
        {
            int counter = 0;
            for (int i = 0; i < arrayToCheck.Length; i++)
            {
                if(arrayToCheck[i]==numberToFind)
                {
                    counter++;
                }
            }
            if(counter==0)
            {
                return -1;
            }
            else
            {
                return counter;
            }
        }

        static void Main(string[] args)
        {
            int[] array = new int[] { 1, 5, 3, 4, 5, 6, 7, 8, 5 };
            int number, result;
            Console.Write("Please enter a number to find : ");
            number = int.Parse(Console.ReadLine());

            result = CountingNumbers(array, number);

            if (result == -1)
            {
                Console.WriteLine("The number doesn't appears into the array!");
            }
            else
            {
                Console.WriteLine("{0} appears {1} times in the array!",number,result);
            }
        }
    }
}
