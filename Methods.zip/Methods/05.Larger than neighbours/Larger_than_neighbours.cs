﻿/*
Problem 5. Larger than neighbours
• Write a method that checks if the element at given position in given array of integers is larger than its two neighbours (when such exist).
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Larger_than_neighbours
{
    class Larger_than_neighbours
    {
        public static string IsBiggerThenNeigh(int[] array,int number,int position)
        {
                if (number == array[position - 1])
                {
                    if (position - 1 == 0)
                    {
                        return WhoIsBigger(number, array[position]) + " right neigbour";
                    }
                    else if (position - 1 == array.Length - 1)
                    {
                        return WhoIsBigger(number, array[position - 2]) + " left neigbour";
                    }
                    else
                    {
                        return WhoIsBigger(number, array[position]) + " right neigbour. " + WhoIsBigger(number, array[position - 2]) + " left neigbour";
                    }
                }
                else
                {
                    return "No such number on the given position.";
                }
        }

        public static string WhoIsBigger(int numberToChek, int numberAtArrayPosition)
        {
            int result = Math.Max(numberToChek, numberAtArrayPosition);
            if(result == numberToChek)
            {
                return "The number is bigger than his ";
            }
            else if (result == numberAtArrayPosition)
            {
                return "The number is lower than his ";
            }
            else
            {
                return "The number is equal to his ";
            }
        }
        static void Main(string[] args)
        {
            int[] array = new int[] { 1, 5, 3, 4, 5, 6, 7, 8, 5 };
            int number;
            Console.Write("Please enter a number to find : ");
            number = int.Parse(Console.ReadLine());

            int position;
            Console.Write("Please enter a position between 1 and {0} : ",array.Length);
            position = int.Parse(Console.ReadLine());

            if (position < 0 || position >= array.Length)
            {
                Console.WriteLine("The position is out of the array range.");
                return;
            }


            //int index = Array.IndexOf(array, 5);
            //Console.WriteLine(index);
            //Console.ReadLine();

            Console.WriteLine(IsBiggerThenNeigh(array,number,position));
        }
    }
}
