﻿/*
Problem 1. Say Hello
• Write a method that asks the user for his name and prints  “Hello, <name>”  
• Write a program to test this method.
 
 Example:

input           output

Peter     Hello, Peter! 

*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Say_Hello
{
    class Say_Hello
    {
        public static void PrintGreeting(string sentString)
        {
            Console.WriteLine("Hello , {0}!",sentString);
        }

        static void Main(string[] args)
        {
            Console.Write("Enter your name :");
            string Name = Console.ReadLine();

            PrintGreeting(Name);
        }
    }
}
