﻿/*
Problem 6. First larger than neighbours
• Write a method that returns the index of the first element in array that is larger than its neighbours, or  -1 , if there’s no such element.
• Use the method from the previous exercise.
 */ 
 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace First_larger_than_neighbours
{
    class First_larger_than_neighbours
    {
        public static int IsBiggerThenNeigh(int[] array)
        {
            for (int i = 1; i < array.Length-1; i++)
            {
                int checkRight = WhoIsBigger(array[i], array[i + 1]);
                int checkLeft = WhoIsBigger(array[i],array[i-1]);
                if(checkLeft==1 && checkRight==1)
                {
                    return i;
                }
            }
            return -1;
        }

        public static int WhoIsBigger(int numberToChek, int neighbour)
        {
            int result = Math.Max(numberToChek, neighbour);
            if (result == numberToChek)
            {
                return 1;
            }
            else
            {
                return -1;
            }
        }
        static void Main(string[] args)
        {
            int[] array = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            int index;

            index = IsBiggerThenNeigh(array);

            if (index == 1)
            {
                Console.WriteLine("The index  is : {0}", index);
            }
            else
            {
                Console.WriteLine("No such element");
            }
        }

    }
}
